function d = Dyc(u)
d = (DyF(u)+DyB(u))/2;
end