close all;
clear all;
clc;

[X,Y]=meshgrid(1:100);
X