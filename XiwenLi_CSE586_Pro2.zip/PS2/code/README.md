(1) Run Euler_Method.m will plot graphs of both part (b) and (c).

(2) Running Geodestic_Shooting_a.m and Geodestic_Shooting_b.m outputs corresponding result image in the same directory respectively.